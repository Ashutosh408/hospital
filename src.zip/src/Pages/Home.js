import React from 'react';

import {Header} from '../Components/Header';
import {Footer} from '../Components/Footer';
import '../css/Home.css';
import {Button, Navbar ,Nav , Form , FormControl} from 'react-bootstrap';   
import ReactDOM from 'react-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHistory , faAmbulance , faUserMd, faSyringe , faUserAlt , faStethoscope , faPills , faDna} from '@fortawesome/free-solid-svg-icons';
 
class Home extends React.Component {
  
  render() {
    return (
        <>
       <Header /> 
        <div className="home-banner">
            <div className="banner-content">
              <div className="container">
              <div className="row">
                  <div className="col-lg-6 col-md-6 col-12 left-side-banner">
                      <h4>The Home of Your Hope</h4>
                      <h1>Our Priority is to Ensure the Good Health of Patients</h1>
                      <p>Get your appointment through online and remain safe at your home. Because your safety is our first priority.</p>
                      <Button className="appointment-btn">Request Appointment</Button>
                  </div>
                  <div className="col-lg-6 col-md-6 col-12 right-side-banner">

                  </div>
                  
                </div>
              </div>
            </div>
        </div>
        <section className="sec_padding">
          <div className="container">
            <div className="row">
              <div className="col-lg-6 col-md-6 col-12">
                  <div className="sec_heading">
                    <div className="sec_sub_head">
                        About Us
                    </div>
                    <div className="sec_main_head">
                        We Are Your Trusted Friend
                    </div>
                  </div>
                  <div className="sec_content">
                    <p>Hospital is a trusted name of Medical Services who is always at your side and your health is our first priority.</p>

                    <p>Hospital Care will be administered through plan-based customizable programs that incorporate partnership between family members and the care givers for long term illness or disease management.</p>
                  </div>
                  <div className="home-about-sec2">
                    <div className="home-about-facility">
                        <div className="home-about-facility-icon bg-theme-red">
                            <FontAwesomeIcon icon={faHistory} />
                        </div>
                        <div className="home-about-facility-text">
                          <h4 className="sec_sub_head">24/7 Support</h4>
                          <p>Our medical team of different department for long term illness writers and editors makes all the</p>
                        </div>
                    </div>
                    <div className="home-about-facility">
                        <div className="home-about-facility-icon bg-theme-red">
                            <FontAwesomeIcon icon={faAmbulance} />
                        </div>
                        <div className="home-about-facility-text">
                          <h4 className="sec_sub_head">Emergency Support</h4>
                          <p>Our medical team of different department for long term illness writers and editors makes all the</p>
                        </div>
                    </div>
                    <Button className="explore-btn main-btn" >Explore More</Button>
                </div>
              </div>

              <div className="col-lg-6">
                <div className="about-right-img">
              <img src="/images/about-img2.jpg" alt="Images"/>
              <div className="about-open-hours">
              <h3>Open Hours</h3>
                <ul>
                    <li>
                      Monday
                      <span>8:00 am - 9:30 pm</span>
                    </li>
                    <li>
                      Tuesday
                      <span>8:00 am - 9:30 pm</span>
                    </li>
                    <li>
                      Wednesday
                      <span>8:00 am - 9:30 pm</span>
                    </li>
                    <li>
                      Thursday
                      <span>8:00 am - 9:30 pm</span>
                    </li>
                    <li>
                      Friday
                      <span>8:00 am - 9:30 pm</span>
                    </li>
                    <li>
                      Saturday
                      <span>8:00 am - 9:30 pm</span>
                    </li>
                    <li>
                    Sunday
                    <span>8:00 am - 9:30 pm</span>
                    </li>
                </ul>
              </div>
              </div>
              </div>
            </div>
          </div>
        </section>


        <section className="service-area sec_padding pt-100 pb-70">
          <div className="container">
            <div className="section-title text-center">
            <h2>Services That We Provide</h2>
              <div className="section-icon">
                <div className="icon">
                
                <FontAwesomeIcon icon={faDna} />
                </div>
              </div>
            <p>
            We provide excellent services for your ultimate good health. Here some of the services are included
            for your better understand that we are always at your side.
            </p>
          </div>
          <div className="row pt-45">
            <div className="col-lg-4 col-md-6">
              <div className="service-item service-item-bg1">
                <a href="javascript:void(0)" className="service-item-icon">
                <FontAwesomeIcon icon={ faUserMd} />
                
                </a>
                <h3>
                <a href="javascript:void(0)">Medical Counselling</a>
                </h3>
                <p>We provide wide range of medical counselling by the professional doctor &amp; therapist.</p>
                <div className="service-shape-1">
                  <img src="/images/service-shape1.png" alt="Images"/>
                </div>
                <div className="service-shape-2">
                  <img src="/images/service-shape2.png" alt="Images"/>
                </div>
            </div>
          </div>
          <div className="col-lg-4 col-md-6">
          <div className="service-item service-item-bg2">
          <a href="javascript:void(0)" className="service-item-icon">
          <FontAwesomeIcon icon={faSyringe } /> 
          </a>
          <h3>
          <a href="javascript:void(0)">Laboratory Test</a>
          </h3>
          <p>We provide wide range of medical counselling by the professional doctor &amp; therapist.</p>
          <div className="service-shape-1">
          <img src="/images/service-shape1.png" alt="Images"/>
          </div>
          <div className="service-shape-2">
          <img src="/images/service-shape2.png" alt="Images"/>
          </div>
          </div>
          </div>
          <div className="col-lg-4 col-md-6">
          <div className="service-item service-item-bg3">
          <a href="javascript:void(0)" className="service-item-icon">
          <FontAwesomeIcon icon={faUserAlt } /> 
          </a>
          <h3>
          <a href="javascript:void(0)">Surgical Operation</a>
          </h3>
          <p>We provide wide range of medical counselling by the professional doctor &amp; therapist.</p>
          <div className="service-shape-1">
          <img src="/images/service-shape1.png" alt="Images"/>
          </div>
          <div className="service-shape-2">
          <img src="/images/service-shape2.png" alt="Images"/>
          </div>
          </div>
          </div>
          <div className="col-lg-4 col-md-6">
          <div className="service-item service-item-bg4">
          <a href="javascript:void(0)" className="service-item-icon">
          <FontAwesomeIcon icon={faStethoscope } />
          </a>
          <h3>
          <a href="javascript:void(0)">Medical Treatment</a>
          </h3>
          <p>We provide wide range of medical counselling by the professional doctor &amp; therapist.</p>
          <div className="service-shape-1">
          <img src="/images/service-shape1.png" alt="Images"/>
          </div>
          <div className="service-shape-2">
          <img src="/images/service-shape2.png" alt="Images"/>
          </div>
          </div>
          </div>
          <div className="col-lg-4 col-md-6">
          <div className="service-item service-item-bg5">
          <a href="javascript:void(0)" className="service-item-icon">
          <FontAwesomeIcon icon={ faPills } />
          </a>

          <h3>
          <a href="javascript:void(0)">Pharmacy Service</a>
          </h3>
          <p>We provide wide range of medical counselling by the professional doctor &amp; therapist.</p>
          <div className="service-shape-1">
          <img src="/images/service-shape1.png" alt="Images"/>
          </div>
          <div className="service-shape-2">
          <img src="/images/service-shape2.png" alt="Images"/>
          </div>
          </div>
          </div>
          <div className="col-lg-4 col-md-6">
          <div className="service-item service-item-bg6">
          <a href="javascript:void(0)" className="service-item-icon">
          <FontAwesomeIcon icon={faAmbulance} />
          </a>
          <h3>
          <a href="javascript:void(0)">Emergency Services</a>
          </h3>
          <p>We provide wide range of medical counselling by the professional doctor &amp; therapist.</p>
          <div className="service-shape-1">
          <img src="/images/service-shape1.png" alt="Images"/>
          </div>
          <div className="service-shape-2">
          <img src="/images/service-shape2.png" alt="Images"/>
          </div>
          </div>
          </div>
          </div>
          </div>
          <div className="service-dots-2">
          </div>
          </section>
          <Footer /> 
        </>
    );
  }
}

export default Home;
