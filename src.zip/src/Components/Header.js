import React from 'react';
import ReactDOM from 'react-dom';
import {Button, Navbar ,Nav , Form , FormControl} from 'react-bootstrap';
import '../css/Header.css';

export class Header extends React.Component {
  
  render() {
    return (
        <>
       
            <div className="header">
              <div className="top-head-main">
                <div className="container">
                  <div className="top-header">
                    <div className="top-head-contact">
                      <ul>
                                                      
                        <li>  contact@hospital.com</li>
                        <li>   Mon - Sat 8:00am - 7:00pm</li>
                      </ul>
                    </div>
                    <div className="top-head-social">
                      <ul>
                        <li></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="container">
                  <Navbar  expand="lg" className="p-3" >
                    <Navbar.Brand href="#home">Hospital</Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse className=""  id="basic-navbar-nav">
                        <Nav  className="ml-auto nav-link-main" >
                          <Nav.Link className="nav-link" href="#home">Home</Nav.Link>
                          <Nav.Link className="nav-link"   href="#link">About </Nav.Link>
                          <Nav.Link className="nav-link"   href="#link">Doctors </Nav.Link>
                          <Nav.Link className="nav-link" href="#link">Services </Nav.Link>
                          <Nav.Link className="nav-link" href="#link">Pharmacy </Nav.Link>
                          <Nav.Link className="nav-link" href="#link">Contact </Nav.Link>
                        </Nav>
      
                        </Navbar.Collapse>
                    </Navbar>
                </div>
            </div>
        </>
    );
  }
}

export default Header;
